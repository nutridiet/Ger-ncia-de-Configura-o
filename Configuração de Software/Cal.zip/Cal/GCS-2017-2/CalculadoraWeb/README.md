# GCS-2017-2
Ambiente destinado às publicações da disciplina "Gerência de Configuração de Software", do Bacharelado em Engenharia de Computação do Centro Universitário de Anápolis-GO.
